package org.iesbelen.tiendainformatica.service;

import org.iesbelen.tiendainformatica.entity.Fabricante;

public interface FabricanteService {

    boolean create(Fabricante fabricante);

    // logica de negocio

    // realizar calculo

}
