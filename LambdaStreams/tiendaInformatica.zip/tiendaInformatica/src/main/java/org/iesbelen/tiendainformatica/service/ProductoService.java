package org.iesbelen.tiendainformatica.service;

import org.iesbelen.tiendainformatica.entity.Producto;

public interface ProductoService {

    boolean create(Producto producto);

    // logica de negocio

    // realizar calculo
}

